from django.urls import path

from . import views

urlpatterns = [
    path("", views.index, name="index"),
    path("api/clientes/", views.cliente_list, name="cliente-list"),
    path("api/clientes/<int:pk>/", views.cliente_detail, name="cliente-detail"),
]
