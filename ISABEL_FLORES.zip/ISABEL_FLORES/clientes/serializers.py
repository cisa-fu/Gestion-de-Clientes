import re

from rest_framework import serializers

from .models import Cliente


class ClienteSerializer(serializers.ModelSerializer):
    fecha_ingreso = serializers.DateField(
        format="%d-%m-%Y",
        input_formats=["%d-%m-%Y"],
        error_messages={"invalid": "La fecha debe tener el formato dd-mm-aaaa (ej: 25-03-2024)."},
    )
    observacion = serializers.CharField(required=False, allow_blank=True, default="")

    class Meta:
        model = Cliente
        fields = ["id", "nombre", "direccion", "telefono", "fecha_ingreso", "zona", "observacion"]

    def validate_telefono(self, value):
        value = value.strip()
        if not re.fullmatch(r"\+?[\d\s\-]{7,20}", value):
            raise serializers.ValidationError("Ingrese un teléfono válido (solo números, espacios, guiones o +).")
        return value
