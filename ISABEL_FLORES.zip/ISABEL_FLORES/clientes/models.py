from django.db import models


class Cliente(models.Model):
    class Zona(models.TextChoices):
        CENTRO = "CENTRO", "Centro"
        PERIFERIA = "PERIFERIA", "Periferia"
        COSTA = "COSTA", "Costa"

    nombre = models.CharField(max_length=100)
    direccion = models.CharField(max_length=200)
    telefono = models.CharField(max_length=20)
    fecha_ingreso = models.DateField()
    zona = models.CharField(max_length=10, choices=Zona.choices)
    observacion = models.TextField(blank=True, default="")

    class Meta:
        ordering = ["id"]

    def __str__(self):
        return f"{self.id} - {self.nombre}"
