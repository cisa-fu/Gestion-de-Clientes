from django.db import migrations, models


class Migration(migrations.Migration):

    initial = True

    dependencies = []

    operations = [
        migrations.CreateModel(
            name="Cliente",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("nombre", models.CharField(max_length=100)),
                ("direccion", models.CharField(max_length=200)),
                ("telefono", models.CharField(max_length=20)),
                ("fecha_ingreso", models.DateField()),
                ("zona", models.CharField(choices=[("CENTRO", "Centro"), ("PERIFERIA", "Periferia"), ("COSTA", "Costa")], max_length=10)),
                ("observacion", models.TextField(blank=True, default="")),
            ],
            options={"ordering": ["id"]},
        ),
    ]
