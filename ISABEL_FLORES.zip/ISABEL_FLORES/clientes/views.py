from django.db.models import Q
from django.shortcuts import get_object_or_404, render
from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response

from .models import Cliente
from .serializers import ClienteSerializer


def index(request):
    return render(request, "clientes/index.html")


@api_view(["GET", "POST"])
def cliente_list(request):

    if request.method == "GET":
        clientes = Cliente.objects.all()
        q = request.query_params.get("q", "").strip()
        if q:
            filtro = (
                Q(nombre__icontains=q)
                | Q(direccion__icontains=q)
                | Q(telefono__icontains=q)
                | Q(zona__icontains=q)
            )
            if q.isdigit():
                filtro |= Q(pk=int(q))
            clientes = clientes.filter(filtro)
        return Response(ClienteSerializer(clientes, many=True).data)

    serializer = ClienteSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(["GET", "PUT", "PATCH", "DELETE"])
def cliente_detail(request, pk):

    cliente = get_object_or_404(Cliente, pk=pk)

    if request.method == "GET":
        return Response(ClienteSerializer(cliente).data)

    if request.method in ("PUT", "PATCH"):
        serializer = ClienteSerializer(cliente, data=request.data, partial=(request.method == "PATCH"))
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    cliente.delete()
    return Response(status=status.HTTP_204_NO_CONTENT)
