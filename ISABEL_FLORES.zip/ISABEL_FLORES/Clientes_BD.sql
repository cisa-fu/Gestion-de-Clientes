CREATE DATABASE IF NOT EXISTS `Clientes_BD` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `Clientes_BD`;

DROP TABLE IF EXISTS `clientes_cliente`;
CREATE TABLE `clientes_cliente` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `direccion` varchar(200) NOT NULL,
  `telefono` varchar(20) NOT NULL,
  `fecha_ingreso` date NOT NULL,
  `zona` varchar(10) NOT NULL,
  `observacion` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;